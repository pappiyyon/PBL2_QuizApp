package com.example.quizapp;

public class QuizBook {

    public static String[] questions = new String []{
      "Pisa building is in Italy.",
      "Taj Mahal is in Peru",
      "Alhambra Palace is in Spain",
      "Stonehenge is in Salisbury",
      "The Great Pyramid of Giza is in Jordan",
      "Petra is in Egypt",
      "Pantheon is in Rome",
      "Blue Mosque is in Turkey",
      "The Acropolis of Athens is in Greece",
      "Porta Nigra is in England ",
    };

    public static int[] images = new int[]{
        R.drawable.pisa, R.drawable.tajmahal, R.drawable.alhambra,R.drawable.stonehenge,
        R.drawable.pyramid, R.drawable.petra, R.drawable.pantheon, R.drawable.bluemosque,
        R.drawable.acropolis, R.drawable.portanigra

    };

    public static boolean[] answers = new boolean[]{
        true, false, true, true, false, false, true, true, true, false
    };
}
